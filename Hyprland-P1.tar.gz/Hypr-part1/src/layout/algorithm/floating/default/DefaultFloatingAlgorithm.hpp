#include "../../FloatingAlgorithm.hpp"

#include <map>

namespace Layout {
    class CAlgorithm;
}

namespace Layout::Floating {
    class CDefaultFloatingAlgorithm : public IFloatingAlgorithm {
      public:
        CDefaultFloatingAlgorithm()          = default;
        virtual ~CDefaultFloatingAlgorithm() = default;

        virtual void newTarget(SP<ITarget> target);
        virtual void movedTarget(SP<ITarget> target, std::optional<Vector2D> focalPoint = std::nullopt);
        virtual void removeTarget(SP<ITarget> target);

        virtual void resizeTarget(const Vector2D& Δ, SP<ITarget> target, eRectCorner corner = CORNER_NONE);
        virtual void moveTarget(const Vector2D& Δ, SP<ITarget> target);

        virtual void setTargetGeom(const CBox& geom, SP<ITarget> target);

        virtual void swapTargets(SP<ITarget> a, SP<ITarget> b);
        virtual void moveTargetInDirection(SP<ITarget> t, Math::eDirection dir, bool silent);

        virtual void updateTarget(SP<ITarget> target) override;

        virtual void recenter(SP<ITarget> t);

      private:
        CBox fitBoxInWorkArea(const CBox& box, SP<ITarget> t, bool fully = true);

        CBox setPositionGlobal(SP<ITarget> t, const CBox& box, uint8_t flags = TARGET_UPDATE_NONE);

        struct SWindowData {
            CBox lastBox;
        };

        std::map<WP<ITarget>, SWindowData> m_datas;
    };
};
