#include "ConfigWatcher.hpp"
#if defined(__linux__)
#include <linux/limits.h>
#endif
#include <sys/inotify.h>
#include "../../../debug/log/Logger.hpp"
#include "../../ConfigValue.hpp"
#include "../../ConfigManager.hpp"
#include <ranges>
#include <unistd.h>
#include <filesystem>

using namespace Hyprutils::OS;
using namespace Config;

UP<CConfigWatcher>& Config::watcher() {
    static UP<CConfigWatcher> p = makeUnique<CConfigWatcher>();
    return p;
}

CConfigWatcher::CConfigWatcher() : m_inotifyFd(inotify_init1(IN_NONBLOCK | IN_CLOEXEC)) {
    if (!m_inotifyFd.isValid()) {
        LOG(Log::ERR, "CConfigWatcher couldn't open an inotify node. Config will not be automatically reloaded");
        return;
    }
}

CFileDescriptor& CConfigWatcher::getInotifyFD() {
    return m_inotifyFd;
}

void CConfigWatcher::update() {
    static const auto PDISABLEAUTORELOAD = CConfigValue<Config::BOOL>("misc:disable_autoreload");
    setWatchList(*PDISABLEAUTORELOAD ? std::vector<std::string>{} : Config::mgr()->getConfigPaths());
}

void CConfigWatcher::setWatchList(const std::vector<std::string>& paths) {

    // we clear all watches first, because whichever fired is now invalid
    // or that is at least what it seems to be.
    // since we don't know which fired,
    // plus it doesn't matter that much, these ops are done rarely and fast anyways.

    // cleanup old paths
    for (auto& watch : m_watches) {
        inotify_rm_watch(m_inotifyFd.get(), watch.wd);
    }

    m_watches.clear();

    // add new paths
    for (const auto& path : paths) {
        std::error_code ecDir;
        const bool      isDirectory   = std::filesystem::is_directory(path, ecDir);
        const uint32_t  fileMask      = IN_CLOSE_WRITE | IN_DONT_FOLLOW;
        const uint32_t  directoryMask = fileMask | IN_CREATE | IN_DELETE | IN_MOVED_TO | IN_MOVED_FROM;
        const uint32_t  mask          = isDirectory ? directoryMask : fileMask;

        m_watches.emplace_back(SInotifyWatch{
            .wd   = inotify_add_watch(m_inotifyFd.get(), path.c_str(), mask),
            .file = path,
        });

        std::error_code ec, ec2;
        const auto      CANONICAL  = std::filesystem::canonical(path, ec);
        const auto      IS_SYMLINK = std::filesystem::is_symlink(path, ec2);
        if (!ec && !ec2 && IS_SYMLINK) {
            m_watches.emplace_back(SInotifyWatch{
                .wd   = inotify_add_watch(m_inotifyFd.get(), CANONICAL.c_str(), IN_CLOSE_WRITE),
                .file = path,
            });
        }
    }
}

void CConfigWatcher::setOnChange(const std::function<void(const SConfigWatchEvent&)>& fn) {
    m_watchCallback = fn;
}

void CConfigWatcher::onInotifyEvent() {
    constexpr size_t                                     BUFFER_SIZE = sizeof(inotify_event) + NAME_MAX + 1;
    alignas(inotify_event) std::array<char, BUFFER_SIZE> buffer      = {};
    const ssize_t                                        bytesRead   = read(m_inotifyFd.get(), buffer.data(), buffer.size());
    if (bytesRead <= 0)
        return;

    for (size_t offset = 0; offset < sc<size_t>(bytesRead);) {
        const auto* ev = rc<const inotify_event*>(buffer.data() + offset);

        if (offset + sizeof(inotify_event) > sc<size_t>(bytesRead)) {
            LOG(Log::ERR, "CConfigWatcher: malformed inotify event, truncated header");
            break;
        }

        if (offset + sizeof(inotify_event) + ev->len > sc<size_t>(bytesRead)) {
            LOG(Log::ERR, "CConfigWatcher: malformed inotify event, truncated name field");
            break;
        }

        const auto WD = std::ranges::find_if(m_watches, [wd = ev->wd](const auto& e) { return e.wd == wd; });

        if (WD == m_watches.end())
            LOG(Log::ERR, "CConfigWatcher: got an event for wd {} which we don't have?!", ev->wd);
        else
            m_watchCallback(SConfigWatchEvent{
                .file = WD->file,
            });

        offset += sizeof(inotify_event) + ev->len;
    }
}
