#include "LuaWorkspace.hpp"
#include "LuaMonitor.hpp"
#include "LuaWindow.hpp"
#include "LuaGroup.hpp"
#include "LuaObjectHelpers.hpp"

#include "../../../managers/fullscreen/FullscreenController.hpp"
#include "../../../workspace/HLWorkspace.hpp"
#include "../../../desktop/view/Group.hpp"
#include "../../../desktop/view/window/WindowGroupMembership.hpp"
#include "../../../output/Monitor.hpp"
#include "../../../layout/space/Space.hpp"
#include "../../../layout/algorithm/Algorithm.hpp"
#include "../../../layout/algorithm/TiledAlgorithm.hpp"
#include "../../../layout/supplementary/WorkspaceAlgoMatcher.hpp"
#include "../../../workspace/RegularWorkspace.hpp"
#include "../../../Compositor.hpp"
#include "workspace/AbstractWorkspace.hpp"

#include <algorithm>
#include <lua.h>
#include <string_view>
#include <variant>

using namespace Config::Lua;

static constexpr const char* MT = "HL.Workspace";

//
static int workspaceEq(lua_State* L) {
    const auto* lhs = sc<PHLWORKSPACEREF*>(luaL_checkudata(L, 1, MT));
    const auto* rhs = sc<PHLWORKSPACEREF*>(luaL_checkudata(L, 2, MT));

    lua_pushboolean(L, lhs->lock() == rhs->lock());
    return 1;
}

static int workspaceToString(lua_State* L) {
    const auto* ref = sc<PHLWORKSPACEREF*>(luaL_checkudata(L, 1, MT));
    const auto  ws  = ref->lock();

    if (!ws)
        lua_pushstring(L, "HL.Workspace(expired)");
    else
        lua_pushfstring(L, "HL.Workspace(%s:%s)", ws->addressableName().c_str(), ws->displayName().c_str());

    return 1;
}

static int workspaceGetWindows(lua_State* L) {
    auto*      ref = sc<PHLWORKSPACEREF*>(luaL_checkudata(L, 1, MT));
    const auto ws  = ref->lock();
    if (!ws) {
        lua_newtable(L);
        return 1;
    }

    lua_newtable(L);
    int idx = 1;
    for (auto const& w : Desktop::windowState()->windows()) {
        if (w->m_workspace == ws) {
            Objects::CLuaWindow::push(L, w);
            lua_rawseti(L, -2, idx++);
        }
    }
    return 1;
}

static int workspaceGetGroups(lua_State* L) {
    auto*      ref = sc<PHLWORKSPACEREF*>(luaL_checkudata(L, 1, MT));
    const auto ws  = ref->lock();
    if (!ws) {
        lua_newtable(L);
        return 1;
    }

    lua_newtable(L);
    int                                 idx = 1;

    std::vector<Desktop::View::CGroup*> pushedGroups;

    for (auto const& w : Desktop::windowState()->windows()) {
        if (w->m_workspace != ws || !w->grouping().group())
            continue;

        if (std::ranges::find(pushedGroups, w->grouping().group().get()) != pushedGroups.end())
            continue;

        pushedGroups.push_back(w->grouping().group().get());

        Objects::CLuaGroup::push(L, w->grouping().group());

        lua_rawseti(L, -2, idx++);
    }

    return 1;
}

static int workspaceIndex(lua_State* L) {
    auto*      ref = sc<PHLWORKSPACEREF*>(luaL_checkudata(L, 1, MT));
    const auto ws  = ref->lock();
    if (!ws) {
        LOG(Log::DEBUG, "[lua] Tried to access an expired object");
        lua_pushnil(L);
        return 1;
    }

    const std::string_view key = luaL_checkstring(L, 2);

    if (key == "name")
        lua_pushstring(L, ws->displayName().c_str());
    else if (key == "addressable_name")
        lua_pushstring(L, ws->addressableName().c_str());
    else if (key == "id") {
        // for compatibility under lua, keep this field populated with a numbered ID if there is one,
        // or nil
        auto id = ws->id();
        if (std::holds_alternative<Workspace::SWorkspaceNumberedID>(id))
            lua_pushinteger(L, std::get<Workspace::SWorkspaceNumberedID>(id).value);
        else
            lua_pushnil(L);
    } else if (key == "monitor") {
        const auto mon = ws->m_monitor.lock();
        if (mon)
            Objects::CLuaMonitor::push(L, mon);
        else
            lua_pushnil(L);
    } else if (key == "windows")
        lua_pushinteger(L, sc<lua_Integer>(ws->getWindowCount()));
    else if (key == "visible")
        lua_pushboolean(L, ws->visible());
    else if (key == "special")
        lua_pushboolean(L, ws->type() == Workspace::eWorkspaceType::SPECIAL);
    else if (key == "active") {
        const auto mon = ws->m_monitor.lock();
        lua_pushboolean(L, mon && (mon->m_activeWorkspace == ws || mon->m_activeSpecialWorkspace == ws));
    } else if (key == "has_urgent")
        lua_pushboolean(L, ws->hasUrgentWindow());
    else if (key == "fullscreen_mode")
        lua_pushinteger(L, sc<lua_Integer>(Fullscreen::controller()->getFullscreenModes(ws).internal));
    else if (key == "has_fullscreen")
        lua_pushboolean(L, Fullscreen::controller()->hasFullscreen(ws));
    else if (key == "is_persistent") {
        const auto REGULAR = dynamicPointerCast<Workspace::CRegularWorkspace>(ws);
        lua_pushboolean(L, REGULAR && REGULAR->isPersistent());
    } else if (key == "is_empty")
        lua_pushboolean(L, ws->getWindowCount() == 0);
    else if (key == "tiled_layout") {
        std::string layoutName = "unknown";
        const auto& SPACE      = ws->space();
        if (SPACE && SPACE->algorithm() && SPACE->algorithm()->tiledAlgo()) {
            const auto& TILED_ALGO = SPACE->algorithm()->tiledAlgo();
            layoutName             = Layout::Supplementary::algoMatcher()->getNameForTiledAlgo(TILED_ALGO.get());
        }
        lua_pushstring(L, layoutName.c_str());
    } else if (key == "last_window") {
        const auto lastWindow = ws->getLastFocusedWindow();
        if (lastWindow)
            Objects::CLuaWindow::push(L, lastWindow);
        else
            lua_pushnil(L);
    } else if (key == "fullscreen_window") {
        const auto fsWindow = Fullscreen::controller()->getFullscreenWindow(ws);
        if (fsWindow)
            Objects::CLuaWindow::push(L, fsWindow);
        else
            lua_pushnil(L);
    } else if (key == "get_windows")
        lua_pushcfunction(L, workspaceGetWindows);
    else if (key == "get_groups")
        lua_pushcfunction(L, workspaceGetGroups);
    else if (key == "groups")
        lua_pushinteger(L, sc<lua_Integer>(ws->getGroups()));
    else
        lua_pushnil(L);

    return 1;
}

void Objects::CLuaWorkspace::setup(lua_State* L) {
    registerMetatable(L, MT, workspaceIndex, gcRef<PHLWORKSPACEREF>, workspaceEq, workspaceToString);
}

void Objects::CLuaWorkspace::push(lua_State* L, PHLWORKSPACE ws) {
    if (!ws) {
        lua_pushnil(L);
        return;
    }

    new (lua_newuserdata(L, sizeof(PHLWORKSPACEREF))) PHLWORKSPACEREF(ws ? ws->m_self : nullptr);
    luaL_getmetatable(L, MT);
    lua_setmetatable(L, -2);
}

void Objects::CLuaWorkspace::push(lua_State* L, PHLWORKSPACEREF ws) {
    if (!ws) {
        lua_pushnil(L);
        return;
    }

    new (lua_newuserdata(L, sizeof(PHLWORKSPACEREF))) PHLWORKSPACEREF(ws ? ws->m_self : nullptr);
    luaL_getmetatable(L, MT);
    lua_setmetatable(L, -2);
}
