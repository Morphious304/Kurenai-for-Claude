#pragma once

#include "IValue.hpp"

#include "../../ConfigValue.hpp"
#include "../../shared/complex/ComplexDataTypes.hpp"

#include <optional>

namespace Config::Values {
    struct SCssGapValueOptions {
        std::optional<double>          min               = std::nullopt;
        std::optional<double>          max               = std::nullopt;
        Supplementary::PropRefreshBits refresh           = 0;
        const char*                    deprecationNotice = nullptr;
    };

    class CCssGapValue : public IValue {
      public:
        CCssGapValue(const char* name, const char* description, double def, SCssGapValueOptions&& options = {});

        virtual ~CCssGapValue() = default;

        virtual const std::type_info* underlying() const override;
        virtual void                  commence() override;

        const Config::CCssGapData&    value() const;
        const Config::CCssGapData&    defaultVal() const;

        const std::optional<double>   m_min, m_max;

      private:
        CConfigValue<Config::IComplexConfigValue> m_val;
        Config::CCssGapData                       m_default;
    };
}
