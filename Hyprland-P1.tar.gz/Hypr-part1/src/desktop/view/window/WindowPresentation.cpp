#include "WindowPresentation.hpp"
#include "WindowCornerGeometry.hpp"

#include "Window.hpp"
#include "../../../animation/AnimationManager.hpp"
#include "../../../config/ConfigValue.hpp"
#include "../../../config/shared/animation/AnimationTree.hpp"
#include "../../../layout/target/Target.hpp"
#include "../../../managers/fullscreen/FullscreenController.hpp"
#include "../../../output/Monitor.hpp"
#include "../../../output/MonitorWindowTransaction.hpp"
#include "../../../protocols/core/Compositor.hpp"
#include "../../../render/decorations/CHyprBorderDecoration.hpp"
#include "../../../render/decorations/CHyprDropShadowDecoration.hpp"
#include "../../../render/decorations/CHyprInnerGlowDecoration.hpp"
#include "../../../render/decorations/DecorationPositioner.hpp"
#include "../../../render/WindowRenderPresentation.hpp"
#include "../../../render/Renderer.hpp"
#include "../../../render/scene/SceneSelection.hpp"
#include "../../state/FocusState.hpp"

#include <algorithm>
#include <array>
#include <utility>

using namespace Desktop;
using namespace Desktop::View;

class CDecorationSnapshot {
  public:
    CDecorationSnapshot(std::span<const SP<IHyprWindowDecoration>> decorations) {
        if (decorations.size() <= m_inline.size()) {
            std::ranges::copy(decorations, m_inline.begin());
            m_decorations = std::span<const SP<IHyprWindowDecoration>>{m_inline}.first(decorations.size());
            return;
        }

        m_fallback.assign(decorations.begin(), decorations.end());
        m_decorations = m_fallback;
    }

    CDecorationSnapshot(const CDecorationSnapshot&)                                  = delete;
    CDecorationSnapshot(CDecorationSnapshot&&)                                       = delete;
    CDecorationSnapshot&                       operator=(const CDecorationSnapshot&) = delete;
    CDecorationSnapshot&                       operator=(CDecorationSnapshot&&)      = delete;

    std::span<const SP<IHyprWindowDecoration>> decorations() const {
        return m_decorations;
    }

  private:
    std::array<SP<IHyprWindowDecoration>, 4>   m_inline;
    std::vector<SP<IHyprWindowDecoration>>     m_fallback;
    std::span<const SP<IHyprWindowDecoration>> m_decorations;
};

CWindowPresentation::CWindowPresentation(CWindow& window) : m_window(window), m_alpha(WINDOW_ALPHA_LAST), m_animationController(&window) {
    ;
}

CWindowPresentation::~CWindowPresentation() = default;

void CWindowPresentation::initialize() {
    const auto WINDOW  = m_window.m_self.lock();
    m_shadowDecoration = makeShared<CHyprDropShadowDecoration>(WINDOW);
    m_borderDecoration = makeShared<CHyprBorderDecoration>(WINDOW);
    m_glowDecoration   = makeShared<CHyprInnerGlowDecoration>(WINDOW);

    addDecorationInternal(m_shadowDecoration);
    addDecorationInternal(m_borderDecoration);
    addDecorationInternal(m_glowDecoration);

    m_borderDecoration->initializeAnimations();
    Animation::mgr()->createAnimation(1.F, alpha(WINDOW_ALPHA_FADE), Config::animationTree()->getAnimationPropertyConfig("fadeIn"), WINDOW, AVARDAMAGE_ENTIRE);
    Animation::mgr()->createAnimation(1.F, alpha(WINDOW_ALPHA_ACTIVE), Config::animationTree()->getAnimationPropertyConfig("fadeSwitch"), WINDOW, AVARDAMAGE_ENTIRE);
    Animation::mgr()->createAnimation(1.F, alpha(WINDOW_ALPHA_FULLSCREEN), Config::animationTree()->getAnimationPropertyConfig("fadeIn"), WINDOW, AVARDAMAGE_ENTIRE);
    Animation::mgr()->createAnimation(1.F, alpha(WINDOW_ALPHA_LAYOUT), Config::animationTree()->getAnimationPropertyConfig("fadeSwitch"), WINDOW, AVARDAMAGE_ENTIRE);
    m_shadowDecoration->initializeAnimations();
    m_glowDecoration->initializeAnimations();
    Animation::mgr()->createAnimation(0.F, m_dimPercent, Config::animationTree()->getAnimationPropertyConfig("fadeDim"), WINDOW, AVARDAMAGE_ENTIRE);
    Animation::mgr()->createAnimation(1.F, alpha(WINDOW_ALPHA_MOVE_TO_WORKSPACE), Config::animationTree()->getAnimationPropertyConfig("fadeOut"), WINDOW, AVARDAMAGE_ENTIRE);
    Animation::mgr()->createAnimation(1.F, alpha(WINDOW_ALPHA_MOVE_FROM_WORKSPACE), Config::animationTree()->getAnimationPropertyConfig("fadeIn"), WINDOW, AVARDAMAGE_ENTIRE);
    Animation::mgr()->createAnimation(0.F, m_notRespondingTint, Config::animationTree()->getAnimationPropertyConfig("fade"), WINDOW, AVARDAMAGE_ENTIRE);
}

std::span<const SP<IHyprWindowDecoration>> CWindowPresentation::decorations() const {
    return m_windowDecorations;
}

bool CWindowPresentation::containsDecoration(const IHyprWindowDecoration* decoration) const {
    return std::ranges::find_if(m_windowDecorations, [decoration](const auto& candidate) { return candidate.get() == decoration; }) != m_windowDecorations.end();
}

SP<IHyprWindowDecoration> CWindowPresentation::decoration(eDecorationType type) const {
    const auto IT = std::ranges::find_if(m_windowDecorations, [type](const auto& candidate) { return candidate->getDecorationType() == type; });
    return IT == m_windowDecorations.end() ? nullptr : *IT;
}

void CWindowPresentation::addDecoration(SP<IHyprWindowDecoration> decoration) {
    if (!decoration)
        return;

    addDecorationInternal(decoration);
    decoration->initializeAnimations();
    decoration->updateState();
    if (m_window.mapped())
        decoration->onWindowMap();

    g_pDecorationPositioner->forceRecalcFor(m_window.m_self.lock());
    updateDecorations();

    if (m_window.layoutTarget())
        m_window.layoutTarget()->recalc();
}

void CWindowPresentation::addDecorationInternal(const SP<IHyprWindowDecoration>& decoration) {
    decoration->setSelf(decoration);
    m_windowDecorations.emplace_back(decoration);
}

void CWindowPresentation::removeDecoration(IHyprWindowDecoration* decoration) {
    if (!decoration || decoration == m_shadowDecoration.get() || decoration == m_borderDecoration.get() || decoration == m_glowDecoration.get())
        return;

    m_decosToRemove.push_back(decoration);
    g_pDecorationPositioner->forceRecalcFor(m_window.m_self.lock());
    updateDecorations();

    if (m_window.layoutTarget())
        m_window.layoutTarget()->recalc();
}

void CWindowPresentation::updateDecorations() {
    for (const auto& pending : m_decosToRemove) {
        const auto IT = std::ranges::find_if(m_windowDecorations, [pending](const auto& decoration) { return decoration.get() == pending; });
        if (IT == m_windowDecorations.end())
            continue;

        g_pDecorationPositioner->uncacheDecoration(IT->get());
        m_windowDecorations.erase(IT);
    }

    m_decosToRemove.clear();

    if (!m_window.mapped() || m_window.isHidden())
        return;

    g_pDecorationPositioner->onWindowUpdate(m_window.m_self.lock());

    const CDecorationSnapshot SNAPSHOT{m_windowDecorations};
    for (const auto& decoration : SNAPSHOT.decorations()) {
        if (!containsDecoration(decoration.get()))
            continue;
        decoration->updateWindow(m_window.m_self.lock());
    }
}

void CWindowPresentation::uncacheDecorations() {
    for (const auto& decoration : m_windowDecorations)
        g_pDecorationPositioner->uncacheDecoration(decoration.get());
}

bool CWindowPresentation::checkInputOnDecorations(eInputType type, const Vector2D& coordinates, std::any data) {
    if (type != INPUT_TYPE_DRAG_END && m_window.hasPopupAt(coordinates))
        return false;

    const CDecorationSnapshot SNAPSHOT{m_windowDecorations};
    for (const auto& decoration : SNAPSHOT.decorations()) {
        if (!containsDecoration(decoration.get()))
            continue;
        if (!(decoration->getDecorationFlags() & DECORATION_ALLOWS_MOUSE_INPUT))
            continue;
        if (!g_pDecorationPositioner->getWindowDecorationBox(decoration.get()).containsPoint(coordinates))
            continue;
        if (decoration->onInputOnDeco(type, coordinates, data))
            return true;
    }

    return false;
}

Types::CMultiAVarContainer<float, uint8_t>& CWindowPresentation::alpha() {
    return m_alpha;
}

const Types::CMultiAVarContainer<float, uint8_t>& CWindowPresentation::alpha() const {
    return m_alpha;
}

PHLANIMVAR<float>& CWindowPresentation::alpha(eWindowAlpha type) {
    return m_alpha.get(type);
}

const PHLANIMVAR<float>& CWindowPresentation::alpha(eWindowAlpha type) const {
    return m_alpha.get(type);
}

float CWindowPresentation::alphaValue(eWindowAlpha type) const {
    return alpha(type)->value();
}

float CWindowPresentation::alphaGoal(eWindowAlpha type) const {
    return alpha(type)->goal();
}

float CWindowPresentation::alphaTotal() const {
    return m_alpha.getTotal();
}

float CWindowPresentation::alphaTotalGoal() const {
    return m_alpha.getTotalGoal();
}

int CWindowPresentation::borderSize() const {
    return m_borderDecoration->borderSize();
}

int CWindowPresentation::renderBorderSize() const {
    return m_borderDecoration->renderBorderSize();
}

double CWindowPresentation::borderExtent() const {
    return m_borderDecoration->borderExtent();
}

void CWindowPresentation::invalidateBorderSize() {
    m_borderDecoration->invalidateBorderSize();
}

bool CWindowPresentation::opaque() const {
    return opaque(renderPresentation());
}

bool CWindowPresentation::opaque(const Render::SWindowRenderPresentation& presentation) const {
    if (alphaValue(WINDOW_ALPHA_FADE) != 1.f || alphaValue(WINDOW_ALPHA_FULLSCREEN) != 1.f || alphaValue(WINDOW_ALPHA_ACTIVE) != 1.f)
        return false;

    if (m_window.wlSurface()->small() && !m_window.wlSurface()->m_fillIgnoreSmall)
        return false;

    if (presentation.workspaceAlpha != 1.f)
        return false;

    auto solitaryResource = m_window.getSolitaryResource();
    if (!solitaryResource || !solitaryResource->m_current.texture)
        return false;

    if (m_window.backend().isX11())
        return solitaryResource->m_current.texture->m_opaque;

    // TODO: this is wrong
    const auto EXTENTS = solitaryResource->m_current.opaque.getExtents();
    if (EXTENTS.w >= solitaryResource->m_current.bufferSize.x && EXTENTS.h >= solitaryResource->m_current.bufferSize.y)
        return true;

    return solitaryResource->m_current.texture->m_opaque;
}

Render::SWindowRenderPresentation CWindowPresentation::renderPresentation() const {
    return renderPresentation(Render::eSceneMode::MONITOR);
}

Render::SWindowRenderPresentation CWindowPresentation::renderPresentation(Render::eSceneMode mode) const {
    return Render::resolveWindowPresentation(renderPresentationState(dynamicPointerCast<Workspace::CWorkspacePresentable>(workspace())), mode);
}

PHLWORKSPACE CWindowPresentation::workspace() const {
    return m_heldWorkspace ? m_heldWorkspace->workspace : m_window.m_workspace;
}

PHLMONITOR CWindowPresentation::monitor() const {
    return m_heldWorkspace ? m_heldWorkspace->monitor.lock() : m_window.m_monitor.lock();
}

bool CWindowPresentation::onSpecialWorkspace() const {
    const auto WORKSPACE = workspace();
    return WORKSPACE && WORKSPACE->type() == Workspace::eWorkspaceType::SPECIAL;
}

bool CWindowPresentation::hasPendingState() const {
    return m_heldWorkspace.has_value() || m_heldFullscreen.has_value();
}

void CWindowPresentation::stageWorkspace() {
    const auto MONITOR = m_window.m_monitor.lock();
    if (m_heldWorkspace || !m_window.canStageGeometry() || !MONITOR || !MONITOR->m_enabled || !MONITOR->m_windowTransaction)
        return;

    // Some assignment paths have already changed m_monitor, but not m_workspace.
    const auto WORKSPACE = m_window.m_workspace;
    holdFullscreenState();
    m_heldWorkspace = SHeldWorkspace{
        .workspace  = WORKSPACE,
        .monitor    = WORKSPACE ? WORKSPACE->m_monitor : m_window.m_monitor,
        .wasVisible = WORKSPACE && WORKSPACE->visible(),
    };
    MONITOR->m_windowTransaction->queue(m_window.m_self.lock(), m_window.geometricBox(IGeometric::GEOMETRIC_GOAL), true);
}

void CWindowPresentation::stageFullscreen() {
    const auto MONITOR = m_window.m_monitor.lock();
    if (!m_window.canStageGeometry() || !MONITOR || !MONITOR->m_enabled || !MONITOR->m_windowTransaction)
        return;

    holdFullscreenState();
    MONITOR->m_windowTransaction->holdFullscreen(m_window.m_workspace);
    MONITOR->m_windowTransaction->queue(m_window.m_self.lock(), m_window.geometricBox(IGeometric::GEOMETRIC_GOAL), true);
}

void CWindowPresentation::holdFullscreenState() {
    if (m_heldFullscreen)
        return;

    const auto WINDOW = m_window.m_self.lock();
    m_heldFullscreen  = Fullscreen::SWindowFullscreenPresentation{
        .modes                 = Fullscreen::controller()->getPresentedFullscreenModes(WINDOW),
        .allowedOverFullscreen = Fullscreen::controller()->isAllowedOverPresentedFullscreen(WINDOW),
    };
}

const std::optional<Fullscreen::SWindowFullscreenPresentation>& CWindowPresentation::heldFullscreenState() const {
    return m_heldFullscreen;
}

bool CWindowPresentation::isFadingOutUnderFullscreen() const {
    return Fullscreen::controller()->getPresentedFullscreenWindow(workspace()) && !Fullscreen::controller()->isAllowedOverPresentedFullscreen(m_window.m_self.lock()) &&
        alpha(WINDOW_ALPHA_FULLSCREEN)->isBeingAnimated() && alphaValue(WINDOW_ALPHA_FULLSCREEN) > 0.F;
}

bool CWindowPresentation::shouldRenderOverFullscreen() const {
    return Fullscreen::controller()->isAllowedOverPresentedFullscreen(m_window.m_self.lock()) || !isFadingOutUnderFullscreen();
}

void CWindowPresentation::setFullscreenAlpha(float value) {
    if (hasPendingState()) {
        m_pendingFullscreenAlpha = value;
        return;
    }

    applyFullscreenAlpha(value);
}

void CWindowPresentation::applyFullscreenAlpha(float value) {
    *alpha(WINDOW_ALPHA_FULLSCREEN) = value;
    static auto PANIMATIONS         = CConfigValue<Config::INTEGER>("animations:enabled");
    if (m_window.m_ruleApplicator->noAnim().valueOr(!*PANIMATIONS || !alpha(WINDOW_ALPHA_FULLSCREEN)->enabled()))
        alpha(WINDOW_ALPHA_FULLSCREEN)->warp();
}

void CWindowPresentation::applyPendingState() {
    const auto WORKSPACE  = std::exchange(m_heldWorkspace, std::nullopt);
    const auto FULLSCREEN = std::exchange(m_heldFullscreen, std::nullopt);
    const auto ALPHA      = std::exchange(m_pendingFullscreenAlpha, std::nullopt);
    if (ALPHA)
        applyFullscreenAlpha(*ALPHA);
    if (WORKSPACE && WORKSPACE->workspace != m_window.m_workspace)
        animateWorkspaceMove(WORKSPACE->workspace, WORKSPACE->wasVisible);
    if (FULLSCREEN) {
        refreshValues();
        static auto PANIMATIONS = CConfigValue<Config::INTEGER>("animations:enabled");
        if (m_window.m_ruleApplicator->noAnim().valueOr(!*PANIMATIONS || !alpha(WINDOW_ALPHA_ACTIVE)->enabled()))
            alpha(WINDOW_ALPHA_ACTIVE)->warp();
    }
}

void CWindowPresentation::discardPendingState() {
    if (!hasPendingState())
        return;

    const auto SELF = m_window.m_self.lock();
    if (g_pHyprRenderer && SELF)
        g_pHyprRenderer->damageWindow(SELF);
    const auto WORKSPACE = std::exchange(m_heldWorkspace, std::nullopt);
    m_heldFullscreen.reset();
    const auto ALPHA = std::exchange(m_pendingFullscreenAlpha, std::nullopt);
    if (ALPHA)
        applyFullscreenAlpha(*ALPHA);
    if (g_pHyprRenderer && SELF)
        g_pHyprRenderer->damageWindow(SELF);
}

void CWindowPresentation::animateWorkspaceMove(PHLWORKSPACE source, bool wasVisible) {
    if (m_heldWorkspace)
        return;

    static auto PANIMATIONS = CConfigValue<Config::INTEGER>("animations:enabled");
    const auto  WARP        = [&](eWindowAlpha channel) {
        if (m_window.m_ruleApplicator->noAnim().valueOr(!*PANIMATIONS || !alpha(channel)->enabled()))
            alpha(channel)->warp();
    };

    if (wasVisible) {
        alpha(WINDOW_ALPHA_MOVE_TO_WORKSPACE)->setValueAndWarp(1.F);
        setMonitorMovedFrom(source ? source->monitorID() : -1);
        *alpha(WINDOW_ALPHA_MOVE_TO_WORKSPACE) = 0.F;
        alpha(WINDOW_ALPHA_MOVE_TO_WORKSPACE)->setCallbackOnEnd([this](auto) {
            alpha(WINDOW_ALPHA_MOVE_TO_WORKSPACE)->setValueAndWarp(1.F);
            resetMonitorMovedFrom();
        });
        WARP(WINDOW_ALPHA_MOVE_TO_WORKSPACE);
    } else if (m_window.m_workspace && m_window.m_workspace->visible()) {
        alpha(WINDOW_ALPHA_MOVE_FROM_WORKSPACE)->setValueAndWarp(0.F);
        *alpha(WINDOW_ALPHA_MOVE_FROM_WORKSPACE) = 1.F;
        WARP(WINDOW_ALPHA_MOVE_FROM_WORKSPACE);
    }
}

Render::SWindowRenderPresentation CWindowPresentation::renderPresentation(const SP<Workspace::CWorkspacePresentable>& presentation) const {
    return Render::resolveWindowPresentation(renderPresentationState(presentation));
}

Render::SWindowPresentationState CWindowPresentation::renderPresentationState(const SP<Workspace::CWorkspacePresentable>& presentation) const {
    // Decoration geometry can be queried before all window animations are initialized.
    const auto ALPHA = [this](eWindowAlpha channel) { return alpha(channel) ? alphaValue(channel) : 1.F; };

    return {
        .workspaceOffset             = presentation ? presentation->m_renderOffset->value() : Vector2D{},
        .floatingOffset              = floatingOffset(),
        .workspaceAlpha              = presentation ? presentation->m_alpha->value() : 1.F,
        .fade                        = ALPHA(WINDOW_ALPHA_FADE),
        .active                      = ALPHA(WINDOW_ALPHA_ACTIVE),
        .fullscreen                  = ALPHA(WINDOW_ALPHA_FULLSCREEN),
        .layout                      = ALPHA(WINDOW_ALPHA_LAYOUT),
        .moveToWorkspace             = ALPHA(WINDOW_ALPHA_MOVE_TO_WORKSPACE),
        .moveFromWorkspace           = ALPHA(WINDOW_ALPHA_MOVE_FROM_WORKSPACE),
        .hasWorkspacePresentation    = !!presentation,
        .workspaceOffsetAnimating    = presentation && presentation->m_renderOffset->isBeingAnimated(),
        .pinned                      = !!(m_window.m_state & WINDOW_STATE_PINNED),
        .movingFromMonitor           = movingFromMonitor(),
        .workspaceVisible            = workspace() && workspace()->visible(),
        .alphaAnimating              = m_alpha.isBeingAnimated(),
        .floatingOffsetFromWorkspace = floatingOffsetSource() == eFloatingOffsetSource::WORKSPACE,
    };
}

Math::SCornerRadii CWindowPresentation::rounding() {
    static auto              PROUNDINGPOWER = CConfigValue<Config::FLOAT>("decoration:rounding_power");

    const float              ROUNDINGPOWER = m_window.m_ruleApplicator->roundingPower().valueOr(*PROUNDINGPOWER);
    const Math::SCornerRadii ROUNDING{m_window.m_ruleApplicator->roundingValue()};

    return effectiveWindowRounding(ROUNDING, ROUNDINGPOWER, m_window.size(IGeometric::GEOMETRIC_CURRENT));
}

float CWindowPresentation::roundingPower() {
    static auto PROUNDINGPOWER = CConfigValue<Config::FLOAT>("decoration:rounding_power");

    return m_window.m_ruleApplicator->roundingPower().valueOr(std::clamp(*PROUNDINGPOWER, 1.F, 10.F));
}

// Check if the point is hidden under a rounded corner. The point is assumed to
// be within the real window box; behavior outside it is undefined.
bool CWindowPresentation::isInCurvedCorner(double x, double y) {
    const auto POSITION = m_window.position(IGeometric::GEOMETRIC_CURRENT);
    const auto SIZE     = m_window.size(IGeometric::GEOMETRIC_CURRENT);
    return isInWindowCorner(Vector2D{x, y} - POSITION, SIZE, rounding(), roundingPower(), borderSize());
}

bool CWindowPresentation::visibleOnMonitor(PHLMONITOR monitor) {
    CBox windowBox = {m_window.position(IGeometric::GEOMETRIC_CURRENT), m_window.size(IGeometric::GEOMETRIC_CURRENT)};

    if (m_window.isFloating())
        windowBox = m_window.getFullWindowBoundingBox();

    return !windowBox.intersection({monitor->m_position, monitor->m_size}).empty();
}

float CWindowPresentation::dimPercent() const {
    return m_dimPercent->value();
}

void CWindowPresentation::setDimPercent(float percent) {
    *m_dimPercent = percent;
}

void CWindowPresentation::warpDimPercent(float percent) {
    m_dimPercent->setValueAndWarp(percent);
}

float CWindowPresentation::notRespondingTint() const {
    return m_notRespondingTint->value();
}

void CWindowPresentation::setNotResponding(bool notResponding) {
    const float GOAL = notResponding ? 0.2F : 0.F;
    if (m_notRespondingTint->goal() != GOAL)
        *m_notRespondingTint = GOAL;
}

const Vector2D& CWindowPresentation::floatingOffset() const {
    return m_floatingOffset.value();
}

eFloatingOffsetSource CWindowPresentation::floatingOffsetSource() const {
    return m_floatingOffset.source();
}

void CWindowPresentation::setFloatingOffset(const Vector2D& offset) {
    m_floatingOffset.set(offset);
}

void CWindowPresentation::clearFloatingOffset() {
    m_floatingOffset.clear();
}

bool CWindowPresentation::movingFromMonitor() const {
    return m_monitorMovedFrom != -1;
}

void CWindowPresentation::setMonitorMovedFrom(int monitor) {
    m_monitorMovedFrom = monitor;
}

void CWindowPresentation::resetMonitorMovedFrom() {
    m_monitorMovedFrom = -1;
}

bool CWindowPresentation::animatingIn() const {
    return m_animatingIn;
}

void CWindowPresentation::setAnimatingIn(bool animating) {
    m_animatingIn = animating;
}

void CWindowPresentation::prepareMap() {
    alpha(WINDOW_ALPHA_ACTIVE)->resetAllCallbacks();
    alpha(WINDOW_ALPHA_FADE)->resetAllCallbacks();
    alpha(WINDOW_ALPHA_FULLSCREEN)->resetAllCallbacks();
    alpha(WINDOW_ALPHA_LAYOUT)->resetAllCallbacks();
    m_dimPercent->resetAllCallbacks();
    alpha(WINDOW_ALPHA_MOVE_TO_WORKSPACE)->resetAllCallbacks();
    alpha(WINDOW_ALPHA_MOVE_FROM_WORKSPACE)->resetAllCallbacks();

    alpha(WINDOW_ALPHA_MOVE_FROM_WORKSPACE)->setValueAndWarp(1.F);
    alpha(WINDOW_ALPHA_MOVE_TO_WORKSPACE)->setValueAndWarp(1.F);
}

void CWindowPresentation::dispatchMap() {
    const CDecorationSnapshot SNAPSHOT{m_windowDecorations};
    for (const auto& decoration : SNAPSHOT.decorations()) {
        if (!containsDecoration(decoration.get()))
            continue;
        decoration->onWindowMap();
    }
}

void CWindowPresentation::setAnimationsToMove() {
    m_window.positionAnimation()->setConfig(Config::animationTree()->getAnimationPropertyConfig("windowsMove"));
    m_animatingIn = false;
}

void CWindowPresentation::onWorkspaceAnimUpdate() {
    if (!m_window.isFloating() || (m_window.m_state & WINDOW_STATE_PINNED) || Fullscreen::controller()->isPresentedFullscreen(m_window.m_self.lock())) {
        clearFloatingOffset();
        return;
    }

    const auto WORKSPACE = workspace();
    if (!WORKSPACE)
        return;

    const auto MONITOR = monitor();
    if (!MONITOR)
        return;

    Vector2D   offset;
    const auto WINDOW_BOX = m_window.getFullWindowBoundingBox();
    if (WORKSPACE->m_renderOffset->value().x != 0) {
        const auto PROGRESS = WORKSPACE->m_renderOffset->value().x / MONITOR->m_size.x;

        if (WINDOW_BOX.x < MONITOR->m_position.x)
            offset.x += (MONITOR->m_position.x - WINDOW_BOX.x) * PROGRESS;
        if (WINDOW_BOX.x + WINDOW_BOX.width > MONITOR->m_position.x + MONITOR->m_size.x)
            offset.x += (WINDOW_BOX.x + WINDOW_BOX.width - MONITOR->m_position.x - MONITOR->m_size.x) * PROGRESS;
    } else if (WORKSPACE->m_renderOffset->value().y != 0) {
        const auto PROGRESS = WORKSPACE->m_renderOffset->value().y / MONITOR->m_size.y;

        if (WINDOW_BOX.y < MONITOR->m_position.y)
            offset.y += (MONITOR->m_position.y - WINDOW_BOX.y) * PROGRESS;
        if (WINDOW_BOX.y + WINDOW_BOX.height > MONITOR->m_position.y + MONITOR->m_size.y)
            offset.y += (WINDOW_BOX.y + WINDOW_BOX.height - MONITOR->m_position.y - MONITOR->m_size.y) * PROGRESS;
    }

    m_floatingOffset.set(offset, eFloatingOffsetSource::WORKSPACE);
}

void CWindowPresentation::onFocusAnimUpdate() {
    const CDecorationSnapshot SNAPSHOT{m_windowDecorations};
    for (const auto& decoration : SNAPSHOT.decorations()) {
        if (!containsDecoration(decoration.get()))
            continue;
        decoration->onWindowFocus();
    }
}

void CWindowPresentation::refreshValues() {
    static auto PINACTIVEALPHA   = CConfigValue<Config::FLOAT>("decoration:inactive_opacity");
    static auto PACTIVEALPHA     = CConfigValue<Config::FLOAT>("decoration:active_opacity");
    static auto PFULLSCREENALPHA = CConfigValue<Config::FLOAT>("decoration:fullscreen_opacity");
    static auto PDIMSTRENGTH     = CConfigValue<Config::FLOAT>("decoration:dim_strength");
    static auto PDIMENABLED      = CConfigValue<Config::BOOL>("decoration:dim_inactive");
    static auto PDIMMODAL        = CConfigValue<Config::BOOL>("decoration:dim_modal");

    const bool  IS_SHADOWED_BY_MODAL = m_window.backend().traits().hasModalChild;

    if (Fullscreen::controller()->isPresentedFullscreen(m_window.m_self.lock(), Fullscreen::FSMODE_FULLSCREEN))
        *alpha(WINDOW_ALPHA_ACTIVE) = m_window.m_ruleApplicator->alphaFullscreen().valueOrDefault().applyAlpha(*PFULLSCREENALPHA);
    else if (m_window.m_self == Desktop::focusState()->window())
        *alpha(WINDOW_ALPHA_ACTIVE) = m_window.m_ruleApplicator->alpha().valueOrDefault().applyAlpha(*PACTIVEALPHA);
    else
        *alpha(WINDOW_ALPHA_ACTIVE) = m_window.m_ruleApplicator->alphaInactive().valueOrDefault().applyAlpha(*PINACTIVEALPHA);

    float goalDim = 1.F;
    if (m_window.m_self == Desktop::focusState()->window() || m_window.m_ruleApplicator->noDim().valueOrDefault() || !*PDIMENABLED)
        goalDim = 0.F;
    else
        goalDim = *PDIMSTRENGTH;

    if (IS_SHADOWED_BY_MODAL && *PDIMMODAL)
        goalDim += (1.F - goalDim) / 2.F;

    setDimPercent(goalDim);

    const CDecorationSnapshot SNAPSHOT{m_windowDecorations};
    for (const auto& decoration : SNAPSHOT.decorations()) {
        if (!containsDecoration(decoration.get()))
            continue;
        decoration->updateState();
    }

    updateDecorations();
}

Animation::SViewAnimationContext CWindowPresentation::animateOut() const {
    return m_animationController.animateOut();
}

void CWindowPresentation::applyAnimateIn() const {
    m_animationController.apply(m_animationController.animateIn());
}
