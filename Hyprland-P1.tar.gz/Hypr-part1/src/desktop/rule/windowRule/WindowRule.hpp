#pragma once

#include "../RuleWithEffects.hpp"
#include "../../DesktopTypes.hpp"
#include "../../types/OverridableVar.hpp"
#include "WindowRuleEffectContainer.hpp"
#include "../../../config/shared/complex/ComplexDataTypes.hpp"
#include "../../../config/shared/complex/CornersData.hpp"
#include "../../../helpers/math/Expression.hpp"
#include "../../../helpers/math/Math.hpp"

#include <expected>
#include <unordered_set>
#include <variant>

namespace Desktop::Rule {
    constexpr const char* EXEC_RULE_ENV_NAME = "HL_EXEC_RULE_TOKEN";

    struct SFullscreenStateRule {
        int                internal = 0;
        std::optional<int> client;
    };

    struct SOpacityRule {
        Types::SAlphaValue alpha;
        Types::SAlphaValue alphaInactive;
        Types::SAlphaValue alphaFullscreen;
    };

    struct SBorderColorRule {
        std::optional<Config::CGradientValueData> active;
        std::optional<Config::CGradientValueData> inactive;
    };

    using WindowRuleEffectValue = std::variant<std::monostate, bool, int64_t, float, std::string, std::vector<std::string>, SFullscreenStateRule, SOpacityRule, SBorderColorRule,
                                               Math::SExpressionVec2, Config::CCornersData>;

    struct SWindowRuleEffect {
        using storageType = CWindowRuleEffectContainer::storageType;
        using valueType   = WindowRuleEffectValue;

        CWindowRuleEffectContainer::storageType key = WINDOW_RULE_EFFECT_NONE;
        std::string                             raw;
        WindowRuleEffectValue                   value;
    };

    class CWindowRule : public CRuleWithEffects<SWindowRuleEffect, RULE_TYPE_WINDOW> {
      private:
        using Base        = CRuleWithEffects<SWindowRuleEffect, RULE_TYPE_WINDOW>;
        using storageType = Base::storageType;

      public:
        CWindowRule(const std::string& name = "");
        virtual ~CWindowRule() = default;

        using Base::addEffect;

        CWindowRule(const CWindowRule&) = default;
        CWindowRule(CWindowRule&)       = default;
        CWindowRule(CWindowRule&&)      = default;

        static std::expected<SP<CWindowRule>, std::string> buildFromExecString(std::string&&);

        std::expected<void, std::string>                   addEffect(storageType e, const Math::SExpressionVec2& expr);

        bool                                               matches(PHLWINDOW w, bool allowEnvLookup = false);
        bool                                               matches(Desktop::Rule::eRuleProperty p, const std::string& s);
        bool                                               matches(Desktop::Rule::eRuleProperty p, bool b);

      private:
        std::expected<WindowRuleEffectValue, std::string> parseEffect(storageType e, const std::string& result) override;
    };
};
