#include "WorkspaceMatchEngine.hpp"
#include "../../../workspace/HLWorkspace.hpp"

using namespace Desktop::Rule;

CWorkspaceMatchEngine::CWorkspaceMatchEngine(const std::string& s) : m_value(s) {
    ;
}

bool CWorkspaceMatchEngine::match(PHLWORKSPACE ws) {
    return ws && ws->matchesStaticSelector(m_value);
}
